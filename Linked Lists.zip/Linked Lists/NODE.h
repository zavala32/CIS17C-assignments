/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NODE.h
 * Author: nick2
 *
 * Created on October 9, 2019, 3:55 PM
 */

#ifndef NODE_H
#define NODE_H

struct Node{
    int data;
    Node *ptr;
};

#endif /* NODE_H */

